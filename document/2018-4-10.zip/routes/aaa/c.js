module.exports=(req, res)=>{
  res.send('c');
};
