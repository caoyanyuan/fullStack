module.exports=(req, res)=>{
  res.send('b');
};
