let mod=require('mod1');
//import mod from 'mod1';

console.log(mod.a, mod.b);
