export default {
  API_ROOT: 'http://localhost:8090'
}
