import {Component} from '@angular/core';

@Component({
  selector: 'site-head',
  templateUrl: './head.component.html'
})

export class HeadComponent{

}
