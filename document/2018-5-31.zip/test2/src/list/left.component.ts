import {Component} from '@angular/core';

@Component({
  selector: 'left-cmp',
  templateUrl: './left.component.html'
})

export class LeftComponent{

}
