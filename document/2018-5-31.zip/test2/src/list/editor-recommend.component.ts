import {Component} from '@angular/core';

@Component({
  selector: 'editor-recommend',
  templateUrl: './editor-recommend.component.html'
})

export class EditorRecommendComponent{

}
