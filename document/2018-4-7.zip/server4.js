const express=require('express');

let server=express();
server.listen(8080);

server.get('/a', (req, res, next)=>{
  console.log('bbbb');

  next();
});

server.get('/a', (req, res, next)=>{
  console.log('aaaa');

  next();
});

server.use(express.static('www/'));
