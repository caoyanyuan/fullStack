let pathlib=require('path');

console.log(pathlib.resolve('../a.txt'));
