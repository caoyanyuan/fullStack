enum Gender{Male, Female};
















let gender:Gender=Gender.Other;

/*switch(gender){
  case Gender.Male:
    console.log('男的');
    break;
  case Gender.Female:
    console.log('女的');
    break;
}*/
