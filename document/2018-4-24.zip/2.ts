//1.变量
//let a:number=12;
//let a:boolean=true;
//let a:string='asdfasdf';
//let a:any

//2.参数
/*function show(a:number, b:number){
  return a+b;
}

console.log(show(12,'5'));*/

//3.返回值
function show(a: number, b: number):number{
  return 'abc';
}

console.log(show(12,5));
