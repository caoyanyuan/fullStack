let json:{a: number, b: number}={a: 12, b: 5};

console.log(json.a);
