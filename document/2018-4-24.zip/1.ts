let a:any=12;
let b=5;

a='abc';

console.log(a+b);
