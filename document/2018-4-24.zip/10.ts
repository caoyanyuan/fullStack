window.onload=function ():void{
  let oDiv:HTMLElement=document.getElementById('div1');

  oDiv.style.background='red';
};
