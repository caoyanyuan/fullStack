let a:(number|string)[]=[1,2,3,'ab'];

console.log(a);

//let a:(number|string)=true;
