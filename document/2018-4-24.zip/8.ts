function sum(a:number=12,b:number=5):number{
  return a+b;
}

console.log(sum());
