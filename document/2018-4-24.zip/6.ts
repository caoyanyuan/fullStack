//let a:void;

function show(name:string, age:number):void{
  console.log(`名字：${name}，年龄：${age}`);
}

show('blue', 18);
