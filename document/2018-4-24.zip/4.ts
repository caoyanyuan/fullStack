let a:[number,boolean]=[12,true];

console.log(a);
