let a:undefined=(()=>{
  return undefined;
})();

console.log(a);
