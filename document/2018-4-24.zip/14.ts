declare window.a;

if(window.a){
  console.log('有');
}else{
  console.log('没');
}
