function show(a:number){
  console.log('1');
}

function show(a:string){
  console.log('2');
}

console.log(show(12));
console.log(show('adfas'));
