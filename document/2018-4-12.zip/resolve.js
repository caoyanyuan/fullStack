const path=require('path');

console.log(path.resolve('aaa', 'bbb', '../', 'ccc', '/', './a.txt'));
