//const express=require('express');
const koa=require('koa');

//let server=express();
let server=new koa();

server.listen(8080);
