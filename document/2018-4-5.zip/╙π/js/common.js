function rnd(n, m){
  return Math.random()*(m-n)+n;
}

function rndInt(n, m){
  return Math.floor(Math.random()*(m-n)+n);
}
