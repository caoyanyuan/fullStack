module.exports={
  //database
  db_host:        '127.0.0.1',
  db_port:        3309,
  db_user:        'root',
  db_pass:        '',
  db_name:        'aaa',

  md5_key:        'sfjd;lkjfzopijppoIJOPIU$RPOI$IH$IUH#%UYFR(*Y$IUHRFLKDSNLKHSDFOIUHOIHTIP#$HI(THUI))',
};
